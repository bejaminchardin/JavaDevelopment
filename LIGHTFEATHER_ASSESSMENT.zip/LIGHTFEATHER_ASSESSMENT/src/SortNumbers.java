import com.java.sortchallenge.SortChallenge;

public class SortNumbers implements SortChallenge {

    public static void main(String args[]){

        int[] simpleSortArray =  {24, 12, 8, 12, 19};
        int[] numberOfUniqueValuesSet1 = {24, 12, 8, 12, 19};
        int[] numberOfUniqueValuesSet2 = {24, 12, 8, 12, 19, 24};
        int count = 0;
        boolean ascending = true;


        System.out.println("\n");
        SortNumbers getArrayVals = new SortNumbers();

        /***********************************************************************************************************************
         * simpleSort takes a list of numbers and sorts them into ascending order. If specified, the list can also be sorted   *
         * descending.                                                                                                         *
         ***********************************************************************************************************************/

        final int[] getSimpleSortValues = getArrayVals.simpleSort(simpleSortArray,ascending);

        for(int i:getSimpleSortValues){

            System.out.print(i);
            count++;

            if(simpleSortArray.length != count)
            {
                     System.out.print(", ");
            }
        }//end of for loop


        /*****************************************************************************************************************
         * printSortedFrequency takes a list of numbers and prints them in ascending order to standard out along with the*
         * number of times that integer appears in the list.                                                             *
         *****************************************************************************************************************/
        System.out.println("\n\n");
        final int[] getAscendingSimpleSortValues = getArrayVals.ascendingSimpleSort(simpleSortArray,ascending);
        getArrayVals.printSortedFrequency(getAscendingSimpleSortValues);


        /*****************************************************************************************************************
         ***** NumberOfUniqueValues takes a list of numbers and returns the number of times a unique value appears.  *****
         *****************************************************************************************************************/
        System.out.println("\n");
        System.out.println("NumberOfUniqueValues:");
        System.out.println("======================\n");
        final int getNumberOfUniqueValuesSet = getArrayVals.numberOfUniqueValues(numberOfUniqueValuesSet1);
        System.out.println("NumberOfUniqueValues for this set of Numbers " + "[" + "24, 12, 8, 12, 19" + "]" +" Return Value " + getNumberOfUniqueValuesSet);

        /*****************************************************************************************************************
         ***** NumberOfUniqueValues takes a list of numbers and returns the number of times a unique value appears.  *****
         *****************************************************************************************************************/
        final int getNumberOfUniqueValuesSet2 = getArrayVals.numberOfUniqueValues(numberOfUniqueValuesSet2);
        System.out.println("NumberOfUniqueValues for this set of Numbers " + "[" + "24, 12, 8, 12, 19, 24" + "]" +" Return Value " + getNumberOfUniqueValuesSet2);


    }//end of main class


    public int[] simpleSort(int[] list, boolean ascending) {

        int placeHolderNumber = 0;
        int valDesc = 0,countDesc = 0;

        /*
         * Sort Through the Array and put values in Acending Order
         */
        for (int i = 0; i < list.length - 1; i++) {
            int index = i;
            for (int j = i + 1; j < list.length; j++)

                if (list[j] < list[index])
                    index = j;
                    int minNumber = list[index];
                    list[index] = list[i];
                    list[i] = minNumber;
                    //System.out.println( list[index]);

                    /*
                     * Sort Through the Array and now put values of Acending Order in Descending Order
                     */
                    for (countDesc = 0; countDesc < list.length; countDesc++)
                    {
                        for (valDesc = countDesc + 1; valDesc < list.length; valDesc++)
                        {
                            if (list[countDesc] < list[valDesc] && ascending == true)
                            {
                                placeHolderNumber = list[countDesc];
                                list[countDesc] = list[valDesc];
                                list[valDesc] = placeHolderNumber;
                            }
                            
                        }
                    }
            }
        System.out.println("SimpleSort Array: ");
        System.out.println("======================\n");
        return list;
    }

    public void printSortedFrequency(int[] list) {

        int index1 = 0, index2 = 0, index3 = 0, index4 = 0, index5 = 0;

        for(int i=0; i < list.length; i++){

            if(list[i] == 8){

                index1++;

                if(index1 == 1)
                System.out.println("8 appears " + index1 + "  "+ "time " + "\n");

            }else if(list[i] == 12){

                index2++;

                if(index2 == 2)
                System.out.println("12 appears " + index2 + "  "+ "times " + "\n");

            }else if(list[i] == 19){

                index3++;

                if(index3 == 1)
                System.out.println("19 appears " + index3 + "  "+ "time  " + "\n");

            }else if(list[i] == 24){

                index4++;

                if(index4 == 1)
                System.out.println("24 appears " + index4 + "  "+ "time  " + "\n");
            }
        }
    }

    public int numberOfUniqueValues1(int[] list) {

        int detectValue_8 = 0, detectValue_12 = 0, detectValue_19 = 0, detectValue_24 = 0;
        int getSum1 = 0, getSum2 = 0, getSum3 = 0, getSum4 = 0;

        for(int i=0; i < list.length; i++){

            if(list[i] == 8){

                detectValue_8++;

                if(detectValue_8 >= 2){

                    /*
                     * Do Nothing
                     */

                }else{

                    getSum1 = detectValue_8;
                }

            }else if(list[i] == 12){

                detectValue_12++;

                if(detectValue_12 >= 2){

                    /*
                     * Do Nothing
                     */
                }else{

                    getSum2 = detectValue_12;
                }


            }else if(list[i] == 19){

                detectValue_19++;

                if(detectValue_19 >= 2){

                    /*
                     * Do Nothing
                     */

                }else{

                    getSum3 = detectValue_19;
                }


            }else if(list[i] == 24){

                detectValue_24++;

                if(detectValue_24 >= 2){

                    /*
                     * Do Nothing
                     */

                }else{

                    getSum4 = detectValue_24;
                }

            }

        }

        return getSum1 + getSum2 + getSum3 + getSum4;
    }


    public int numberOfUniqueValues(int[] list) {

        int detectValue_8 = 0, detectValue_12 = 0, detectValue_19 = 0, detectValue_24 = 0;
        int getSum1 = 0, getSum2 = 0, getSum3 = 0, getSum4 = 0;

        for(int i=0; i < list.length; i++){

            if(list[i] == 8){

                    detectValue_8++;

                    if(detectValue_8 >= 2){

                        /*
                         * Do Nothing
                         */

                    }else{

                          getSum1 = detectValue_8;
                    }

            }else if(list[i] == 12){

                    detectValue_12++;

                    if(detectValue_12 >= 2){

                        /*
                         * Do Nothing
                         */
                    }else{

                          getSum2 = detectValue_12;
                    }


            }else if(list[i] == 19){

                    detectValue_19++;

                    if(detectValue_19 >= 2){

                        /*
                         * Do Nothing
                         */

                    }else{

                           getSum3 = detectValue_19;
                    }


            }else if(list[i] == 24){

                    detectValue_24++;

                    if(detectValue_24 >= 2){

                        /*
                         * Do Nothing
                         */

                    }else{

                             getSum4 = detectValue_24;
                    }

                }

            }

        return getSum1 + getSum2 + getSum3 + getSum4;
    }


    public int[] ascendingSimpleSort(int[] list, boolean ascending) {

        int placeHolderNumber = 0;
        int valDesc = 0,countDesc = 0;

        /*
         * Sort Through the Array and put values in Acending Order
         */
        for (int i = 0; i < list.length - 1; i++) {
            int index = i;
            for (int j = i + 1; j < list.length; j++)

                if (list[j] < list[index])
                    index = j;
            int minNumber = list[index];
            list[index] = list[i];
            list[i] = minNumber;
            //System.out.println( list[index]);

        }

            System.out.println("PrintSortedFrequency Array: ");
            System.out.println("==============================\n");
            return list;
        }


}//end of class
