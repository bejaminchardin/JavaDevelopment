package com.perrone.robotics.missionnotes;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FileSearch {

    public static String getPath = new String();
    public static String getPathOfFile = new String();
    private String fileNameToSearch;
    private List<String> result = new ArrayList<String>();
    private String showFilePath;


    public FileSearch() {
    }

    /*
        <!---------------------------------------------------------------------->
        <!---------------------------------------------------------------------->
        <!---------------------------------------------------------------------->
     */
    public static void main(String[] args) {


        FileSearch fileSearch = new FileSearch();

        //try different directory and filename :)
        fileSearch.searchDirectory(new File("C:\\Liebherr Logs\\LME\\client-liebherr\\logs\\LME\\"), "sticky-notes.txt");

        int count = fileSearch.getResult().size();
        if(count ==0){
            System.out.println("\nNo result found!");
        }else{
            System.out.println("\nFound " + count + " result!\n");
            for (String matched : fileSearch.getResult()){
                System.out.println("Found : " + matched);
            }
        }
    }


   /*
        <!---------------------------------------------------------------------->
        <!---------------------------------------------------------------------->
        <!---------------------------------------------------------------------->
     */


    public static String getFilePath(String filePath, String fileName) {

        FileSearch fileSearch = new FileSearch();

        //try different directory and filename :)
        fileSearch.searchDirectory(new File(filePath), fileName );

        int count = fileSearch.getResult().size();

        if(count ==0){
            System.out.println("\nNo result found!");
        }else{
            //System.out.println("\nFound " + count + " result!\n");
            for (String matched : fileSearch.getResult()){
                //System.out.println("Found : " + matched);
                getPath = new String(matched);
                //System.out.println("1) I am in the for loop with get Path and here are the results   " + getPath);
            }
            //System.out.println("2) I am in the for loop with get Path and here are the results   " + getPath);
        }
        getPathOfFile = getPath;

        //System.out.println("3) Here is the result of getFilePath Method and the results are  "  + getPathOfFile);

        return getPathOfFile;
    }


    /*
        <!---------------------------------------------------------------------->
        <!---------------------------------------------------------------------->
        <!---------------------------------------------------------------------->
     */


    public void searchDirectory(File directory, String fileNameToSearch) {

        setFileNameToSearch(fileNameToSearch);

        if (directory.isDirectory()) {
            search(directory);
        } else {
            System.out.println(directory.getAbsoluteFile() + " is not a directory!");
        }
    }

    /*
        <!---------------------------------------------------------------------->
        <!---------------------------------------------------------------------->
        <!---------------------------------------------------------------------->
     */

    private void search(File file) {

        if (file.isDirectory()) {
            //System.out.println("Searching directory ... " + file.getAbsoluteFile());

            //do you have permission to read this directory?
            if (file.canRead()) {
                for (File temp : file.listFiles()) {
                    if (temp.isDirectory()) {
                        search(temp);
                    } else {
                        if (getFileNameToSearch().equals(temp.getName().toLowerCase())) {
                            result.add(temp.getAbsoluteFile().toString());
                        }

                    }
                }

            } else {
                System.out.println(file.getAbsoluteFile() + "Permission Denied");
            }
        }

    }
    public String getFileNameToSearch() {
        return fileNameToSearch;
    }

    public void setFileNameToSearch(String fileNameToSearch) {
        this.fileNameToSearch = fileNameToSearch;
    }

    public List<String> getResult() {
        return result;
    }

    public String getShowFilePath() {
        return showFilePath;
    }

    public void setShowFilePath(String showFilePath) {
        this.showFilePath = showFilePath;
    }

}
