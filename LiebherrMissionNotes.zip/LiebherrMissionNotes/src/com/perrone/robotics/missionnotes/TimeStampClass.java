package com.perrone.robotics.missionnotes;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeStampClass {

    static public void main(String[] args) {

        Date thisDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-YYYY_HH-mm-ss");
        System.out.println(dateFormat.format(thisDate));

        TimeStampClass insert = new TimeStampClass();
        System.out.println(insert.getDate("MM-dd-YYYY_HH-mm-ss"));
    }

    public String getDate(String Date){

        Date thisDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-YYYY_HH-mm-ss");

        return dateFormat.format(thisDate).toString();
    }
}
