package com.perrone.robotics.missionnotes;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class CreationDate {

    public static void main(String[] args) throws IOException {

        InsertDateStamp getTheLatestDirectory = new InsertDateStamp();

        Properties prop = new Properties();
        // load a properties file for reading
        prop.load(new FileInputStream("C:\\Users\\User\\workspace\\WORK_PROJECTS\\PERRONE_ROBOTICS_PROJECT\\LiebherrMissionNotes\\src\\com\\perrone\\robotics\\missionnotes\\properties\\MissionRun.properties"));
        // get the properties and print
        prop.list(System.out);
        //Reading each property value
        prop.getProperty("missionrun.filepath");

        //System.out.println("Here is the prop path" + prop.getProperty("missionrun.filepath"));

        String getDirectoryName = getTheLatestDirectory.getLatestDirCreation("C:\\Liebherr Logs\\LME\\client-liebherr\\logs\\LME" + "\\");
        System.out.println("Here is the Directory Name  " + getDirectoryName);


        String insertDirPath = new String( prop.getProperty("missionrun.filepath")+"\\"+ getDirectoryName);
        System.out.println("Here is the Appended Path of the Directory  " + insertDirPath);
        File dirName = new File(insertDirPath);


        String insert = new String(CreationDate.getCreationDateTime(insertDirPath,dirName).toString());
        String directoryDateCreation = new String(insert);
        System.out.println("Here is the Full Path  " + directoryDateCreation);
    }


    public static String getCreationDateTime(String filePath, File dirName) {

        dirName = new File(filePath);

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        System.out.println("After Format : " + sdf.format(dirName.lastModified()));

        return sdf.format(dirName.lastModified()).toString();
    }

}

 class InsertDateStamp {

    public String getLatestDirCreation(String Dirpath){

        File f = new File(Dirpath);
        File[] files = f.listFiles();
        String getDirectory=null;
        Arrays.sort(files, new Comparator() {
            /**
             * Compares its two arguments for order.  Returns a negative integer,
             * zero, or a positive integer as the first argument is less than, equal
             * to, or greater than the second.<p>
             * <p>
             * In the foregoing description, the notation
             * <tt>sgn(</tt><i>expression</i><tt>)</tt> designates the mathematical
             * <i>signum</i> function, which is defined to return one of <tt>-1</tt>,
             * <tt>0</tt>, or <tt>1</tt> according to whether the value of
             * <i>expression</i> is negative, zero or positive.<p>
             * <p>
             * The implementor must ensure that <tt>sgn(compare(x, y)) ==
             * -sgn(compare(y, x))</tt> for all <tt>x</tt> and <tt>y</tt>.  (This
             * implies that <tt>compare(x, y)</tt> must throw an exception if and only
             * if <tt>compare(y, x)</tt> throws an exception.)<p>
             * <p>
             * The implementor must also ensure that the relation is transitive:
             * <tt>((compare(x, y)&gt;0) &amp;&amp; (compare(y, z)&gt;0))</tt> implies
             * <tt>compare(x, z)&gt;0</tt>.<p>
             * <p>
             * Finally, the implementor must ensure that <tt>compare(x, y)==0</tt>
             * implies that <tt>sgn(compare(x, z))==sgn(compare(y, z))</tt> for all
             * <tt>z</tt>.<p>
             * <p>
             * It is generally the case, but <i>not</i> strictly required that
             * <tt>(compare(x, y)==0) == (x.equals(y))</tt>.  Generally speaking,
             * any comparator that violates this condition should clearly indicate
             * this fact.  The recommended language is "Note: this comparator
             * imposes orderings that are inconsistent with equals."
             *
             * @param o1 the first object to be compared.
             * @param o2 the second object to be compared.
             * @return a negative integer, zero, or a positive integer as the
             * first argument is less than, equal to, or greater than the
             * second.
             * @throws NullPointerException if an argument is null and this
             *                              comparator does not permit null arguments
             * @throws ClassCastException   if the arguments' types prevent them from
             *                              being compared by this comparator.
             */
            @Override
            public int compare(Object o1, Object o2) {
                return 0;
            }

            public int compare(File f1, File f2) {

                return Long.valueOf(f1.lastModified()).compareTo(f2.lastModified());
            }
        });
        int count=0;
        boolean result = f.isDirectory();
        if (result) {
            System.out.println(f.getAbsolutePath() + " is a directory");
            System.out.println("***** Listing all files on the directory *****");
            // listing the files
            String[] list = f.list();
            //System.out.println("Files of the directory: ");

            for (int i = 0; i < files.length; i++) {

                if(f.isDirectory()) {
                    if(    /*
                     * If any of the file name or file extension exist in the most
                     * recent created directory ignore these files.  My program can
                     * not decipher between a directory or a file.
                     */

                            (files[i].getName().indexOf("MissonNotes")  != -1) ||
                                    (files[i].getName().indexOf("fusedObstacles")  != -1) ||
                                    (files[i].getName().indexOf("gtmposlog")  != -1) ||
                                    (files[i].getName().indexOf("MissonNotes")  != -1) ||
                                    (files[i].getName().indexOf("MissonNotes")  != -1) ||
                                    (files[i].getName().indexOf("MAXRobotLogOutput")  != -1)||
                                    (files[i].getName().indexOf("obstacles")  != -1)||
                                    (files[i].getName().indexOf("pose")  != -1)||
                                    (files[i].getName().indexOf("progress")  != -1)||
                                    (files[i].getName().indexOf("rpkstatus")  != -1)||
                                    (files[i].getName().indexOf("telemetry")  != -1)||
                                    (files[i].getName().indexOf(".txt")  != -1)||
                                    (files[i].getName().indexOf(".pdf")  != -1)||
                                    (files[i].getName().indexOf(".rtf")  != -1)||
                                    (files[i].getName().indexOf(".bat")  != -1)||
                                    (files[i].getName().indexOf(".dll")  != -1)||
                                    (files[i].getName().indexOf(".xls")  != -1)||
                                    (files[i].getName().indexOf(".doc")  != -1)||
                                    (files[i].getName().indexOf(".docx")  != -1)||
                                    (files[i].getName().indexOf(".csv")  != -1)||
                                    (files[i].getName().indexOf(".htm")  != -1)||
                                    (files[i].getName().indexOf(".html")  != -1)||
                                    (files[i].getName().indexOf(".odt")  != -1)||
                                    (files[i].getName().indexOf(".xls")  != -1)||
                                    (files[i].getName().indexOf(".xlsx")  != -1)||
                                    (files[i].getName().indexOf(".ods")  != -1)||
                                    (files[i].getName().indexOf(".ppt")  != -1)||
                                    (files[i].getName().indexOf(".pptx")  != -1)||
                                    (files[i].getName().indexOf(".rar")  != -1)||
                                    (files[i].getName().indexOf(".tar.gz")  != -1)||
                                    (files[i].getName().indexOf(".z")  != -1)||
                                    (files[i].getName().indexOf(".zip")  != -1)||
                                    (files[i].getName().indexOf(".bin")  != -1)||
                                    (files[i].getName().indexOf(".log")  != -1)||
                                    (files[i].getName().indexOf(".sql")  != -1)||
                                    (files[i].getName().indexOf(".tar")  != -1)||
                                    (files[i].getName().indexOf(".xml")  != -1)||
                                    (files[i].getName().indexOf(".wma")  != -1)||
                                    (files[i].getName().indexOf(".mdb")  != -1)||
                                    (files[i].getName().indexOf(".sav")  != -1)||
                                    (files[i].getName().indexOf(".vcd")  != -1)||
                                    (files[i].getName().indexOf(".ios")  != -1)||
                                    (files[i].getName().indexOf(".exe")  != -1)||
                                    (files[i].getName().indexOf(".jar")  != -1)||
                                    (files[i].getName().indexOf(".com")  != -1)||
                                    (files[i].getName().indexOf(".ttf")  != -1)||
                                    (files[i].getName().indexOf(".otf")  != -1)||
                                    (files[i].getName().indexOf(".bmp")  != -1)||
                                    (files[i].getName().indexOf(".gif")  != -1)||
                                    (files[i].getName().indexOf(".jpg")  != -1)||
                                    (files[i].getName().indexOf(".png")  != -1)||
                                    (files[i].getName().indexOf(".tif")  != -1)||
                                    (files[i].getName().indexOf(".tiff")  != -1)
                    ){

                        //System.out.println("Word has been captured");

                    }else {
                        //System.out.println("Did i come here  " + files[i].getName());
                        getDirectory = files[i].getName();
                    }



                }//end of if

            }//end of for
        }
        System.out.println();

        //System.out.println("Latest File is: " + getDirectory);
        System.out.println();
        File file = new File(files[files.length - 1].getPath());

        return getDirectory;
    }
}