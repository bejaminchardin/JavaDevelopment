package com.perrone.robotics.missionnotes;

import java.util.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This is a closs to compare the
 * Date of the new Liebherr Folder
 * To see if it was created today.
 *
 * @author Benjamin C. Hardin Sr.
*/
public class TodaysDate {

    Date getTodaysDate;

    public static void main(String[] args)
    {
        TodaysDate formatDate = new TodaysDate();
        formatDate.GetTodaysDate();
    }

    public String GetTodaysDate(){

        // create a calendar instance, and get the date from that
        // instance; it defaults to "today", or more accurately,
        // "now".
       Date getTodaysDate = Calendar.getInstance().getTime();
        // print out today's date
        //System.out.println(getTodaysDate);

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        System.out.println(dateFormat.format(getTodaysDate));

        return dateFormat.format(getTodaysDate);
    }

}
