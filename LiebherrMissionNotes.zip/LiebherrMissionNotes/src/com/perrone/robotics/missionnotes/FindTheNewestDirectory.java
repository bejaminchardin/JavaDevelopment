package com.perrone.robotics.missionnotes;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FindTheNewestDirectory<count> {

    static int  count;
    static int checkValue;
    static Integer getNumSubDir;
    private static String getSubDirName;
    private static String getData;

    public static void  main(String[] args) {

        File dirPath;
        Long i = Long.valueOf(0);
        String selectSubDirectory="";
        List<Long> dirList;

        File insert = new File("C:\\Liebherr Logs\\LME\\client-liebherr\\logs\\LME");
        /****
         * Get the Number of subdirectories in the LME directory
         */
        getNumSubDir = getNumSubDirectories(insert);

        System.out.println("Here are the number of subdirectories " +  getNumSubDirectories(insert) + "\n");

    }


    public long getLatestModifiedDate(File dirPath) {

        File[] files = dirPath.listFiles();
        long latestDate = 0;

        for (File file : files) {

            long fileModifiedDate = file.isDirectory() ? getLatestModifiedDate(file) : file.lastModified();

            if (fileModifiedDate > latestDate) {

                latestDate = fileModifiedDate;

            }//if statement
            ArrayList<Long> dirList = new ArrayList<Long>();
            dirList.add(latestDate);
            Object object = Collections.max(dirList);
            Collections.sort(dirList); // Sort the arraylist
            dirList.get(dirList.size() - 1); //gets the last item, largest for an ascendin
        }

        count++;
        checkValue = count;
        //System.out.println("here is getNumSubDir  " + getNumSubDir);
        //System.out.println("here is count " + count);
        //System.out.println("here is checkValue  " + checkValue);

        if((dirPath.getName() == "LME")){

            /***
             * Do Nothing because this is the root directory
             */
            System.out.println("here is count  " + count);
        }
        else if((checkValue== getNumSubDir) && (getNumSubDir == count) ){

                //System.out.println("Here is the latest Subdirectory that has recently been created. "+  dirPath.getName() +"\n");

                String getSubDirName = getNameSubdirectory(dirPath.getName());
                 setGetData(dirPath.getName());

                //System.out.println("Here is the ID for this folder " +  dirList.get(dirList.size() - 1) +"\n");
        }
        return Math.max(latestDate, dirPath.lastModified());

    }//end of method


    public static int getNumSubDirectories(File filePath){
        int getNumber=0;
        int totalNumSubDir = 0;

        File folder = new File(String.valueOf(filePath));

        File[] files = folder.listFiles();

        for (File file : files)
        {
            if (file.isDirectory())
            {
                //System.out.println(file.getName());

                getNumber++;
            }
        }
        totalNumSubDir = getNumber;

        return totalNumSubDir;

    }//end of method



    public static String getNameSubdirectory(String subDirectory){

        String selectSubDirectory = null;
        if(subDirectory != null) {

                selectSubDirectory = subDirectory;

            }else{
                   System.out.println("The Directory that you are looking for does not exist!! ");
            }

        return selectSubDirectory;

    }//end of method

    public static String getGetData() {
        return getData;
    }

    public void setGetData(String getData) {
        this.getData = getData;
    }


}//end of class



